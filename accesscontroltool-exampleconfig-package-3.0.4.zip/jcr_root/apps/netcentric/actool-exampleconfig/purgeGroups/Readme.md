Deletes the groups "group-to-delete-1", "group-to-delete-2" and "group-to-delete-3".
