Defines a simple group with a single ACL. The config depends on run mode.
* testgroup.author: installed on author only
* testgroup.author.dev,author.test: installed only on author environments that have a second run mode dev or test 