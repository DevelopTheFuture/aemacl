The subfolders include examples for ACTool configurations.

* [multipleFiles](multipleFiles): multiple config files in one directory
* [purgeGroups](purgeGroups): delete obsolete groups
* [runmodes](runmodes): run mode specific configurations
* [simple](simple): just one simple configuration file
* [realProject](realProject): configuration that can be used as a template for real projects
