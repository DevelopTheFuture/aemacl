This includes the ACLs for a real project with three roles:

* Content Managers (contentmanagers): read and write all content/DAM/tags + DTM cloud configs + assign users to project groups
* Power Users (powerusers): read and write all content/DAM/tags + DTM cloud configs
* Technical Support (techsupport): read all content/DAM/tags/packages

There are also service users to read content/tags/users.

You can use the fragment and project groups as template for your own projects.